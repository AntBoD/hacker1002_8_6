

<?php 
 $p = 'Приветствую Вас на моей страничке!';
?>

<?php 
 $name = 'Александр';
 $surname = 'Иванов';
 $city = 'Москва';
 $age = 28;
?>


<?php
include 'main.php';
?>
